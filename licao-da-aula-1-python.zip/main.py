__author__ = 'Thauane'

a = int(input('digite um numero: '))
b = int(input('digite um numero: '))

c = a + b

print(c)

print('========================================')

sal = float(input('digite seu salario: ').replace(',','.'))
porc = float(input('digite a porcentagem do aumento: ').replace(',','.'))
novosal = sal*porc+sal
print('O aumento do seu salário foi de R$%.2f '%novosal)